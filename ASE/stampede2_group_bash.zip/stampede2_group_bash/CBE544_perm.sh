#!/bin/sh

if [ -d $WORK/CBE544 ]
then
    chmod -R g+rx $WORK/CBE544
else 
    echo "please create folder named CBE544 under \$WORK and perform you calculations there"
    echo "Following the instructions here: https://cbe544.github.io/Clusters/#first-time"
fi
